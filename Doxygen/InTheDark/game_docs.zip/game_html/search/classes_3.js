var searchData=
[
  ['gameobject',['GameObject',['../class_game_object.html',1,'']]],
  ['gamestatus',['GameStatus',['../struct_game_status.html',1,'']]]
];
