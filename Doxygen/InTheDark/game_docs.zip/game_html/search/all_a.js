var searchData=
[
  ['parsegameconfig',['parseGameConfig',['../class_config_parser.html#a10df472c5623bc93112f531ba82e7179',1,'ConfigParser']]],
  ['parselevel',['parseLevel',['../class_config_parser.html#a2021c03d8175fa8c1f348ac872dd2812',1,'ConfigParser']]],
  ['platformergame',['PlatformerGame',['../class_platformer_game.html',1,'PlatformerGame'],['../class_platformer_game.html#a2a6af977e2bea8568e759835dafd4101',1,'PlatformerGame::PlatformerGame()']]],
  ['play',['play',['../class_platformer_game.html#a8518927178334a34ae76fd2f595a4ada',1,'PlatformerGame']]],
  ['player',['Player',['../class_player.html',1,'']]],
  ['playerinvulncount',['playerInvulnCount',['../struct_game_status.html#a597d995b4782025d38dfc3731c0c21e4',1,'GameStatus']]],
  ['playmusic',['playMusic',['../class_s_f_x_manager.html#a29fa52df3d70ed7f599d91155d95b73e',1,'SFXManager']]],
  ['playsfx',['playSFX',['../class_s_f_x_manager.html#a1fca8b37f374eeba06b88994f3180a4c',1,'SFXManager']]],
  ['preventcollision',['preventCollision',['../class_enemy.html#ac8e3567182ba81200f35a0a4faabb7d2',1,'Enemy::preventCollision()'],['../class_game_object.html#ae6d3ae25dbdad093de5bcde27a69604c',1,'GameObject::preventCollision()'],['../class_player.html#ae0d2adea38e7cff55a8d4668522069f5',1,'Player::preventCollision()']]]
];
