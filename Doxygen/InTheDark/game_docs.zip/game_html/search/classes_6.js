var searchData=
[
  ['platformergame',['PlatformerGame',['../class_platformer_game.html',1,'']]],
  ['player',['Player',['../class_player.html',1,'']]]
];
