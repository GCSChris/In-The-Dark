var searchData=
[
  ['setmusicvolume',['setMusicVolume',['../class_s_f_x_manager.html#a5b5b2ed8152f2ac6f9bd6a8f60d2796a',1,'SFXManager']]],
  ['setvelocity',['setVelocity',['../class_game_object.html#a59a9a6e2a680fb691b95f5fffcb1e36c',1,'GameObject']]]
];
