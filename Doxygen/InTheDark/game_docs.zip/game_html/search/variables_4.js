var searchData=
[
  ['spriteindex',['spriteIndex',['../class_tile.html#a512d47942f714af58963b566a59027a3',1,'Tile']]],
  ['spritesheet',['spriteSheet',['../class_tile.html#afd5af99d21f2f4a2ec8a8d0f52fad8f8',1,'Tile']]],
  ['state',['state',['../struct_game_status.html#a1f4fea420fcad22d6c0989ef8abd85c5',1,'GameStatus']]]
];
