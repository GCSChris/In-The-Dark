var searchData=
[
  ['playerinvulncount',['playerInvulnCount',['../struct_game_status.html#a597d995b4782025d38dfc3731c0c21e4',1,'GameStatus']]]
];
