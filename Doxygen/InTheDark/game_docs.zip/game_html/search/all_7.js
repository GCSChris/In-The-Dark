var searchData=
[
  ['jump',['jump',['../class_player.html#a70e21ca98281b7d72f105f2693113d7e',1,'Player']]]
];
