var searchData=
[
  ['inst_5f',['inst_',['../struct_game_status.html#a1297f179c899ffafc02886b9b483fc0c',1,'GameStatus']]]
];
