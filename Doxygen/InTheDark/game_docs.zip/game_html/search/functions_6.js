var searchData=
[
  ['level',['Level',['../class_level.html#a7a696c928ca5d5354db6e50e46d0f67d',1,'Level']]],
  ['loadlocalization',['loadLocalization',['../class_localization_manager.html#a278342d9119287ffad3165b175194d17',1,'LocalizationManager']]],
  ['localize',['localize',['../class_localization_manager.html#ad446c8c501e67a530571e841275cbfcb',1,'LocalizationManager']]]
];
