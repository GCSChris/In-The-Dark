var searchData=
[
  ['getimgdimensions',['getIMGDimensions',['../class_resource_manager.html#a34fedb10e38facab256e2a6a157b33c4',1,'ResourceManager']]],
  ['gettexturefromimage',['getTextureFromImage',['../class_resource_manager.html#aa18a4e878cbd693d8ef2efab8e9a1017',1,'ResourceManager']]]
];
