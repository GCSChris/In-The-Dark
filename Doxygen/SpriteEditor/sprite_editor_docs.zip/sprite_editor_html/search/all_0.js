var searchData=
[
  ['cleanup',['cleanUp',['../class_resource_manager.html#a791c04bc270e2618d296e28787c45098',1,'ResourceManager::cleanUp()'],['../class_sprite_editor.html#a609bce7879c1aebd289c8d86e034f105',1,'SpriteEditor::cleanUp()']]]
];
