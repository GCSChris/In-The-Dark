var searchData=
[
  ['init',['init',['../class_level.html#a1b7d0b4f509a9300a494247aae75181a',1,'Level::init()'],['../class_tile_editor.html#a1497dc2871e91a95ab29ab8cd209c21e',1,'TileEditor::init()']]],
  ['instance',['instance',['../class_parser.html#a082b4962bd5cf66c7b515ea8adc402c0',1,'Parser::instance()'],['../class_resource_manager.html#a575597c974ab420c8ec99ba273a91079',1,'ResourceManager::instance()']]]
];
